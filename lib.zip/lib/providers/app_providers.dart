import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/todo_item.dart';
import '../models/speech_segment.dart';
import '../data/database_helper.dart';
import '../services/asr_platform_service.dart';
import '../services/model_manager_service.dart';

/// Provider for database helper
final databaseHelperProvider = Provider<DatabaseHelper>((ref) {
  return DatabaseHelper.instance;
});

/// Provider for ASR platform service
final asrPlatformServiceProvider = Provider<ASRPlatformService>((ref) {
  final service = ASRPlatformService();
  ref.onDispose(() => service.dispose());
  return service;
});

/// Provider for model manager service
final modelManagerServiceProvider = Provider<ModelManagerService>((ref) {
  return ModelManagerService();
});

/// State for recording status
enum RecordingState { idle, recording, processing }

class RecordingNotifier extends Notifier<RecordingState> {
  @override
  RecordingState build() => RecordingState.idle;

  /// Start recording with platform service
  Future<void> start() async {
    final asrService = ref.read(asrPlatformServiceProvider);
    
    // Configure audio
    const config = AudioConfig(
      sampleRate: 16000,
      channels: 1,
      format: 'pcm16',
    );
    
    try {
      final success = await asrService.startRecording(config);
      
      if (success) {
        state = RecordingState.recording;
      } else {
        // Show error to user
        throw Exception('Failed to start recording');
      }
    } catch (e) {
      // Reset state on error
      state = RecordingState.idle;
      rethrow;
    }
  }

  /// Stop recording with platform service
  Future<void> stop() async {
    final asrService = ref.read(asrPlatformServiceProvider);
    
    try {
      await asrService.stopRecording();
      state = RecordingState.processing;
      
      // Simulate processing delay (in real app, this would wait for actual processing)
      await Future.delayed(const Duration(milliseconds: 500));
      
      state = RecordingState.idle;
    } catch (e) {
      state = RecordingState.idle;
      rethrow;
    }
  }

  void reset() => state = RecordingState.idle;
}

final recordingStateProvider = NotifierProvider<RecordingNotifier, RecordingState>(() {
  return RecordingNotifier();
});

/// Notifier for current partial transcript
class PartialTranscriptNotifier extends Notifier<String> {
  @override
  String build() => '';

  void update(String newText) {
    state = newText;
  }
}

/// State for current partial transcript
final partialTranscriptProvider = NotifierProvider<PartialTranscriptNotifier, String>(() {
  return PartialTranscriptNotifier();
});

/// State for all todo items
class TodoListNotifier extends AsyncNotifier<List<TodoItem>> {
  /// Load all todos from database
  Future<void> loadTodos() async {
    final dbHelper = ref.read(databaseHelperProvider);
    final todos = await dbHelper.getAllTodos(sortByOrder: true);
    state = AsyncValue.data(todos);
  }

  @override
  Future<List<TodoItem>> build() async {
    // Load todos on initialization
    final dbHelper = ref.read(databaseHelperProvider);
    final todos = await dbHelper.getAllTodos(sortByOrder: true);
    return todos;
  }

  /// Add a new todo from speech segment
  Future<void> addFromSegment(SpeechSegment segment) async {
    final dbHelper = ref.read(databaseHelperProvider);
    
    final todo = TodoItem(
      id: segment.segmentId,
      text: segment.text,
      createdAt: DateTime.now(),
      audioPath: segment.audioPath,
      confidence: segment.confidence,
      status: TodoStatus.pending,
    );
    
    await dbHelper.insertTodo(todo);
    await loadTodos();
  }

  /// Toggle todo completion status
  Future<void> toggleStatus(String id) async {
    final dbHelper = ref.read(databaseHelperProvider);
    await dbHelper.toggleStatus(id);
    await loadTodos();
  }

  /// Update todo text
  Future<void> updateText(String id, String newText) async {
    final dbHelper = ref.read(databaseHelperProvider);
    final todo = await dbHelper.getTodoById(id);
    if (todo != null) {
      final updated = todo.copyWith(text: newText);
      await dbHelper.updateTodo(updated);
      await loadTodos();
    }
  }

  /// Delete a todo
  Future<void> deleteTodo(String id) async {
    final dbHelper = ref.read(databaseHelperProvider);
    await dbHelper.deleteTodo(id);
    await loadTodos();
  }

  /// Reorder todos
  Future<void> reorderTodos(int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }
    
    final currentValue = state.value ?? [];
    final items = List<TodoItem>.from(currentValue);
    final item = items.removeAt(oldIndex);
    items.insert(newIndex, item);
    
    // Update order indices
    final orderMap = <String, int>{};
    for (int i = 0; i < items.length; i++) {
      orderMap[items[i].id] = i;
    }
    
    final dbHelper = ref.read(databaseHelperProvider);
    await dbHelper.updateOrderIndices(orderMap);
    
    state = AsyncValue.data(items);
  }
}

final todoListProvider = AsyncNotifierProvider<TodoListNotifier, List<TodoItem>>(() {
  return TodoListNotifier();
});

/// VAD configuration provider
class VADConfigNotifier extends Notifier<VADConfig> {
  @override
  VADConfig build() => const VADConfig();

  void updateConfig(VADConfig newConfig) {
    state = newConfig;
  }
}

final vadConfigProvider = NotifierProvider<VADConfigNotifier, VADConfig>(() {
  return VADConfigNotifier();
});
