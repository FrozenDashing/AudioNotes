import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/todo_item.dart';

/// Database helper for managing todo items
class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('audionotes.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
      onOpen: (db) async {
        // Enable foreign keys support
        await db.execute('PRAGMA foreign_keys=ON');
      },
    );
  }

  Future<void> _createDB(Database db, int version) async {
    const idType = 'TEXT PRIMARY KEY';
    const textType = 'TEXT NOT NULL';
    const intType = 'INTEGER NOT NULL';
    const realType = 'REAL';
    const nullableTextType = 'TEXT';
    const nullableIntType = 'INTEGER';

    await db.execute('''
      CREATE TABLE todo_item (
        id $idType,
        text $textType,
        created_at $intType,
        updated_at $nullableIntType,
        audio_path $nullableTextType,
        status INTEGER DEFAULT 0,
        order_index $nullableIntType,
        confidence $realType,
        meta $nullableTextType
      )
    ''');

    await db.execute('CREATE INDEX idx_created_at ON todo_item(created_at)');
    await db.execute('CREATE INDEX idx_order_index ON todo_item(order_index)');
  }

  /// Insert a new todo item
  Future<TodoItem> insertTodo(TodoItem todo) async {
    final db = await database;
    
    await db.insert(
      'todo_item',
      todo.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    
    return todo;
  }

  /// Get all todo items sorted by created_at or order_index
  Future<List<TodoItem>> getAllTodos({bool sortByOrder = false}) async {
    final db = await database;
    
    final orderBy = sortByOrder ? 'order_index ASC, created_at ASC' : 'created_at DESC';
    
    final maps = await db.query(
      'todo_item',
      orderBy: orderBy,
    );

    return maps.map((map) => TodoItem.fromJson(map)).toList();
  }

  /// Get a single todo item by ID
  Future<TodoItem?> getTodoById(String id) async {
    final db = await database;
    
    final maps = await db.query(
      'todo_item',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return TodoItem.fromJson(maps.first);
    }
    return null;
  }

  /// Update a todo item
  Future<int> updateTodo(TodoItem todo) async {
    final db = await database;
    
    return await db.update(
      'todo_item',
      todo.copyWith(updatedAt: DateTime.now()).toJson(),
      where: 'id = ?',
      whereArgs: [todo.id],
    );
  }

  /// Delete a todo item
  Future<int> deleteTodo(String id) async {
    final db = await database;
    
    return await db.delete(
      'todo_item',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// Update order indices for multiple items
  Future<void> updateOrderIndices(Map<String, int> orderMap) async {
    final db = await database;
    final batch = db.batch();
    
    orderMap.forEach((id, orderIndex) {
      batch.update(
        'todo_item',
        {'order_index': orderIndex},
        where: 'id = ?',
        whereArgs: [id],
      );
    });
    
    await batch.commit(noResult: true);
  }

  /// Toggle completion status
  Future<TodoItem?> toggleStatus(String id) async {
    final todo = await getTodoById(id);
    if (todo == null) return null;
    
    final newStatus = todo.status == TodoStatus.pending 
        ? TodoStatus.completed 
        : TodoStatus.pending;
    
    final updated = todo.copyWith(status: newStatus);
    await updateTodo(updated);
    return updated;
  }

  /// Close database connection
  Future<void> close() async {
    final db = await database;
    db.close();
  }
}
